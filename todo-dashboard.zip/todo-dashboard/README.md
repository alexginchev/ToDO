# Todo App — React Kanban Dashboard

A responsive React + Vite todo dashboard based on the supplied UI screenshot.

## Run locally

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually http://localhost:5173).

## Features

- Three-column Kanban board; drag cards between To do, In Progress, and Done
- Create, edit, delete, and move tasks using the + and three-dot menus
- Search, minimum-progress filter, and sorting
- Month-switching calendar; click a date to filter tasks and click again to clear
- Alternate list view and overview totals
- Light/dark theme toggle from the sidebar
- Tasks and theme persist in browser localStorage
- Responsive desktop/tablet/mobile design

Note: This frontend is self-contained; it does not use a server or user authentication. Sidebar destinations other than Calendar and Theme are UI placeholders.
