import React, { useState, useEffect, useMemo } from 'react';
import { createRoot } from 'react-dom/client';
import { Menu, Search, Bell, UserCircle, Settings, CalendarDays, Users, ListTodo, Sun, Moon, CircleHelp, Info, Megaphone, RefreshCw, ChevronRight, ChevronLeft, ChevronDown, Plus, MoreHorizontal, MessageCircle, Link2, SlidersHorizontal, ArrowUpDown, X, Trash2, Pencil, Check, LayoutGrid, List, GripVertical, LogOut } from 'lucide-react';
import './styles.css';

const initialTasks = [
  {id:1,title:'Mobile App Design',status:'todo',progress:50,comments:3,links:5,day:'2026-11-22'},
  {id:2,title:'UI/UX Design',status:'todo',progress:85,comments:3,links:5,day:'2026-11-22'},
  {id:3,title:'Product Design',status:'todo',progress:40,comments:3,links:5,day:'2026-11-22'},
  {id:4,title:'Web App Design',status:'todo',progress:85,comments:3,links:5,day:'2026-11-22'},
  {id:5,title:'Website Design',status:'progress',progress:75,comments:3,links:5,day:'2026-11-22'},
  {id:6,title:'Website Design',status:'progress',progress:70,comments:3,links:5,day:'2026-11-22'},
  {id:7,title:'Web App Design',status:'progress',progress:90,comments:3,links:5,day:'2026-11-22'},
  {id:8,title:'Product Design',status:'progress',progress:50,comments:3,links:5,day:'2026-11-22'},
  {id:9,title:'Website Design',status:'done',progress:30,comments:3,links:5,day:'2026-11-22'},
  {id:10,title:'Finance App Design',status:'done',progress:40,comments:3,links:5,day:'2026-11-22'},
  {id:11,title:'To do App',status:'done',progress:30,comments:3,links:5,day:'2026-11-22'},
  {id:12,title:'Web App Design',status:'done',progress:40,comments:3,links:5,day:'2026-11-22'}
];
const columns = [{id:'todo',name:'To do List'}, {id:'progress',name:'In Progress'}, {id:'done',name:'Done'}];
const navSections = [
  [{icon:UserCircle,name:'Account'},{icon:Settings,name:'General'},{icon:CalendarDays,name:'Calendar'}],
  [{icon:Users,name:'Productivity'},{icon:ListTodo,name:'Reminders'},{icon:Sun,name:'Theme'}],
  [{icon:CircleHelp,name:'Help & Feedback'},{icon:Info,name:'About'},{icon:Megaphone,name:"What’s New"},{icon:RefreshCw,name:'Sync'}]
];
function storageGet(key, fallback) { try { const value=localStorage.getItem(key);return value?JSON.parse(value):fallback; } catch{return fallback;} }
function formatDate(date) { return new Date(`${date}T12:00:00`).toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'}); }
function App(){
  const [tasks,setTasks]=useState(()=>storageGet('todo-board-tasks',initialTasks));
  const [theme,setTheme]=useState(()=>storageGet('todo-board-theme','light'));
  const [search,setSearch]=useState('');
  const [tab,setTab]=useState('All');
  const [filterOpen,setFilterOpen]=useState(false);
  const [sortOpen,setSortOpen]=useState(false);
  const [sort,setSort]=useState('Default');
  const [minProgress,setMinProgress]=useState(0);
  const [sidebarOpen,setSidebarOpen]=useState(false);
  const [selectedNav,setSelectedNav]=useState('');
  const [modal,setModal]=useState(null);
  const [form,setForm]=useState({title:'',description:'Wireframing, Colors, Fonts',status:'todo',progress:0,day:'2026-11-22'});
  const [menuId,setMenuId]=useState(null);
  const [month,setMonth]=useState(()=>new Date(2026,10,1));
  const [selectedDate,setSelectedDate]=useState('');
  const [toast,setToast]=useState('');
  useEffect(()=>localStorage.setItem('todo-board-tasks',JSON.stringify(tasks)),[tasks]);
  useEffect(()=>{localStorage.setItem('todo-board-theme',JSON.stringify(theme));document.documentElement.dataset.theme=theme;},[theme]);
  useEffect(()=>{if(!toast)return;const t=setTimeout(()=>setToast(''),2500);return()=>clearTimeout(t)},[toast]);
  const filtered=useMemo(()=>{
    let items=tasks.filter(t=>t.title.toLowerCase().includes(search.toLowerCase()) && t.progress>=minProgress && (!selectedDate || t.day===selectedDate));
    if(sort==='Name A–Z')items=[...items].sort((a,b)=>a.title.localeCompare(b.title));
    if(sort==='Highest progress')items=[...items].sort((a,b)=>b.progress-a.progress);
    if(sort==='Lowest progress')items=[...items].sort((a,b)=>a.progress-b.progress);
    return items;
  },[tasks,search,minProgress,sort,selectedDate]);
  const updateTask=(id,patch)=>setTasks(prev=>prev.map(t=>t.id===id?{...t,...patch}:t));
  const openCreate=(status='todo')=>{setForm({title:'',description:'Wireframing, Colors, Fonts',status,progress:0,day:selectedDate||'2026-11-22'});setModal({type:'create'});};
  const openEdit=(task)=>{setForm({...task});setModal({type:'edit',id:task.id});setMenuId(null);};
  const saveTask=(e)=>{e.preventDefault();if(!form.title.trim())return;if(modal.type==='create'){setTasks(p=>[...p,{...form,title:form.title.trim(),id:Date.now(),comments:0,links:0}]);setToast('Task created');}else{updateTask(modal.id,{...form,title:form.title.trim()});setToast('Task updated');}setModal(null);};
  const deleteTask=(id)=>{setTasks(p=>p.filter(t=>t.id!==id));setMenuId(null);setModal(null);setToast('Task deleted');};
  const handleNav=(name)=>{setSelectedNav(name);setSidebarOpen(false);if(name==='Theme')setTheme(p=>p==='light'?'dark':'light');else if(name==='Calendar')document.querySelector('.calendar-panel')?.scrollIntoView({behavior:'smooth',block:'center'});else if(name==='Sync')setToast('Your tasks are saved locally');else setToast(`${name} selected`);};
  const monthLabel=month.toLocaleString('en-US',{month:'short',year:'numeric'});
  const startOffset=new Date(month.getFullYear(),month.getMonth(),1).getDay();
  const monthDays=new Date(month.getFullYear(),month.getMonth()+1,0).getDate();
  const dayCells=Array.from({length:startOffset+monthDays},(_,i)=>i-startOffset+1);
  const asDate=(day)=>`${month.getFullYear()}-${String(month.getMonth()+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
  const todaysTasks=tasks.filter(t=>t.status!=='done').slice(0,4);
  return <div className="page-shell"><div className="app">
    {sidebarOpen && <button className="mobile-shade" aria-label="Close menu" onClick={()=>setSidebarOpen(false)}/>}
    <aside className={`sidebar ${sidebarOpen?'sidebar-open':''}`}>
      <div className="brand"><button className="icon-button hamburger" aria-label="Toggle menu" onClick={()=>setSidebarOpen(v=>!v)}><Menu size={21}/></button><strong>Todo App</strong></div>
      <div className="sidebar-groups">{navSections.map((section,i)=><div className="nav-section" key={i}>{section.map(({icon:Icon,name})=><button key={name} onClick={()=>handleNav(name)} className={`nav-item ${selectedNav===name?'nav-selected':''}`}><Icon size={18} strokeWidth={1.75}/><span>{name}</span><ChevronRight className="nav-chevron" size={17}/></button>)}</div>)}</div>
      <div className="sidebar-bottom"><div className="avatar">JD</div><div><strong>Jamie Doe</strong><small>Personal workspace</small></div><button className="icon-button" title="Account" onClick={()=>handleNav('Account')}><MoreHorizontal size={18}/></button></div>
    </aside>
    <main className="main-content">
      <header className="topbar"><button className="icon-button mobile-menu" aria-label="Open sidebar" onClick={()=>setSidebarOpen(true)}><Menu size={22}/></button><div className="searchbar"><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search" aria-label="Search tasks"/><Search size={19} strokeWidth={1.6}/></div><div className="header-actions"><button className="icon-button notification" title="Notifications" onClick={()=>setToast('You’re all caught up!')}><Bell size={19}/><span/></button><div className="avatar top-avatar">JD</div></div></header>
      <div className="content-top"><div className="tabs">{['All','Overview','Project','List'].map(t=><button key={t} className={tab===t?'active':''} onClick={()=>setTab(t)}>{t}</button>)}</div><div className="toolbar"><div className="popover-parent"><button className={`toolbar-btn ${filterOpen?'tool-active':''}`} onClick={()=>{setFilterOpen(v=>!v);setSortOpen(false)}}><SlidersHorizontal size={15}/>Filters{minProgress>0&&<span className="filter-dot"/>}</button>{filterOpen&&<div className="popover"><div className="popover-heading">Filter tasks <button onClick={()=>setFilterOpen(false)} aria-label="Close filters"><X size={16}/></button></div><label>Minimum progress: {minProgress}%</label><input type="range" min="0" max="100" step="10" value={minProgress} onChange={e=>setMinProgress(+e.target.value)}/><button className="clear-filter" onClick={()=>{setMinProgress(0);setSelectedDate('')}}>Clear filters</button></div>}</div><div className="popover-parent"><button className="toolbar-btn" onClick={()=>{setSortOpen(v=>!v);setFilterOpen(false)}}><ArrowUpDown size={15}/>Sort <ChevronDown size={13}/></button>{sortOpen&&<div className="popover sort-popover">{['Default','Name A–Z','Highest progress','Lowest progress'].map(s=><button key={s} className="sort-option" onClick={()=>{setSort(s);setSortOpen(false)}}>{s}{sort===s&&<Check size={15}/>}</button>)}</div>}</div><button className="primary-add" onClick={()=>openCreate()}><Plus size={17}/> New task</button></div></div>
      {tab==='Overview'&&<div className="overview"><span>{tasks.length} total tasks</span><span>{tasks.filter(t=>t.status==='progress').length} in progress</span><span>{tasks.filter(t=>t.status==='done').length} done</span></div>}
      <div className={`workspace ${tab==='List'?'list-mode':''}`}>
        <section className="board" aria-label="Task board">{columns.map(col=><div className={`board-column status-${col.id}`} key={col.id}><div className="column-header"><span>{col.name}</span><span className="column-count">{filtered.filter(t=>t.status===col.id).length}</span><button className="column-plus" title={`Add to ${col.name}`} aria-label={`Add task to ${col.name}`} onClick={()=>openCreate(col.id)}><Plus size={18}/></button></div><div className="task-stack" onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault();const id=Number(e.dataTransfer.getData('task-id'));if(id)updateTask(id,{status:col.id});}}>{filtered.filter(t=>t.status===col.id).map(task=><article className="task-card" key={task.id} draggable onDragStart={e=>{e.dataTransfer.setData('task-id',String(task.id));e.dataTransfer.effectAllowed='move';}}><div className="task-title-row"><div><h3>{task.title}</h3><p>{task.description||'Wireframing, Colors, Fonts'}</p></div><div className="card-menu-parent"><button className="dots" aria-label={`Options for ${task.title}`} onClick={()=>setMenuId(menuId===task.id?null:task.id)}><MoreHorizontal size={18}/></button>{menuId===task.id&&<div className="card-dropdown"><button onClick={()=>openEdit(task)}><Pencil size={14}/> Edit task</button>{columns.filter(c=>c.id!==task.status).map(c=><button key={c.id} onClick={()=>{updateTask(task.id,{status:c.id});setMenuId(null);}}><ArrowUpDown size={14}/> Move to {c.name}</button>)}<button className="danger" onClick={()=>deleteTask(task.id)}><Trash2 size={14}/> Delete task</button></div>}</div></div><div className="progress-label">Progress {task.progress}%</div><div className="progress-track"><div className="progress-fill" style={{width:`${task.progress}%`}}/></div><div className="task-footer"><span className="date-pill">{formatDate(task.day)}</span><div className="task-metrics"><span title="Comments"><MessageCircle size={15}/>{task.comments}</span><span title="Attachments"><Link2 size={15}/>{task.links}</span></div></div></article>)}{filtered.filter(t=>t.status===col.id).length===0&&<div className="empty-column">No tasks here<br/><button onClick={()=>openCreate(col.id)}>Add a task</button></div>}</div></div>)}</section>
        <aside className="right-rail"><section className="panel calendar-panel"><div className="panel-heading"><h2>Calendar</h2></div><div className="calendar-navigation"><button title="Previous month" onClick={()=>setMonth(d=>new Date(d.getFullYear(),d.getMonth()-1,1))}><ChevronLeft size={16}/></button><strong>{monthLabel}</strong><button title="Next month" onClick={()=>setMonth(d=>new Date(d.getFullYear(),d.getMonth()+1,1))}><ChevronRight size={16}/></button></div><div className="calendar-grid">{['S','M','T','W','T','F','S'].map((day,i)=><span className="weekday" key={i}>{day}</span>)}{dayCells.map((day,i)=>day>0?<button key={i} className={`calendar-day ${selectedDate===asDate(day)?'selected-day':''} ${tasks.some(t=>t.day===asDate(day))?'has-tasks':''}`} onClick={()=>setSelectedDate(selectedDate===asDate(day)?'':asDate(day))}>{day}</button>:<span key={i}/>)}</div>{selectedDate&&<button className="date-filter-note" onClick={()=>setSelectedDate('')}>Showing {formatDate(selectedDate)} <X size={13}/></button>}</section><section className="panel today-panel"><div className="panel-heading"><h2>Today's Project</h2><button title="Add a task" onClick={()=>openCreate()}><Plus size={17}/></button></div><div className="today-list">{todaysTasks.map(task=><button className="today-card" key={task.id} onClick={()=>openEdit(task)}><strong>{task.title}</strong><small>{task.description||'Wireframing, Colors, Fonts'}</small></button>)}</div></section></aside>
      </div>
    </main>
    {modal&&<div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setModal(null)}}><form className="task-modal" onSubmit={saveTask}><div className="modal-heading"><div><h2>{modal.type==='create'?'Create new task':'Edit task'}</h2><p>Keep your project moving forward.</p></div><button type="button" className="icon-button" onClick={()=>setModal(null)} aria-label="Close"><X size={20}/></button></div><label>Task name<input required autoFocus value={form.title} onChange={e=>setForm(p=>({...p,title:e.target.value}))} placeholder="e.g. Landing Page Design"/></label><label>Description<input value={form.description} onChange={e=>setForm(p=>({...p,description:e.target.value}))} placeholder="What needs to be done?"/></label><div className="form-row"><label>Status<select value={form.status} onChange={e=>setForm(p=>({...p,status:e.target.value}))}>{columns.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label><label>Due date<input type="date" value={form.day} onChange={e=>setForm(p=>({...p,day:e.target.value}))}/></label></div><label>Progress — {form.progress}%<input type="range" min="0" max="100" step="5" value={form.progress} onChange={e=>setForm(p=>({...p,progress:+e.target.value}))}/></label><div className="modal-actions">{modal.type==='edit'&&<button type="button" className="delete-action" onClick={()=>deleteTask(modal.id)}><Trash2 size={16}/> Delete</button>}<button type="button" className="cancel-action" onClick={()=>setModal(null)}>Cancel</button><button type="submit" className="save-action">{modal.type==='create'?'Create task':'Save changes'}</button></div></form></div>}
    {toast&&<div role="status" className="toast"><Check size={17}/>{toast}</div>}
  </div></div>;
}

createRoot(document.getElementById('root')).render(<App/>);
